"""
Odoo XMLRPC Wrapper

A simple Python to make CRUD process easier
"""

__version__ = "1.0.1"
__author__ = 'Cagatay URESIN'
